// server/routes/skinbloomsRoutes.js
const express = require('express');
const router = express.Router();
const { getOverview, getSalesTrend, getTopProducts } = require('../controllers/skinbloomsController');

router.get('/overview', getOverview);
router.get('/sales-trend', getSalesTrend);
router.get('/top-products', getTopProducts);

module.exports = router;

