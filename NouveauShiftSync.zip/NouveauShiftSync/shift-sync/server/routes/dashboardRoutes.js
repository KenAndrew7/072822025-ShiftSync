// server/routes/dashboardRoutes.js
const express = require('express');
const router = express.Router();
const { getDashboardKPIs, getDashboardRecent } = require('../controllers/dashboardController');

// GET /api/dashboard/kpis - Get aggregated KPIs for dashboard
router.get('/kpis', getDashboardKPIs);

// GET /api/dashboard/recent - Get recent data for mini-tables
router.get('/recent', getDashboardRecent);

module.exports = router;
