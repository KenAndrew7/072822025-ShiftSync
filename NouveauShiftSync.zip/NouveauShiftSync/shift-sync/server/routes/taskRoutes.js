// server/routes/taskRoutes.js
const express = require('express');
const router = express.Router();
const { getAllTasks, notifyTaskUpdate, updateTaskStatus } = require('../controllers/taskController');

router.get('/', getAllTasks);
router.post('/:id/notify', notifyTaskUpdate);
router.put('/:id', updateTaskStatus);

module.exports = router;
