// server/routes/notificationRoutes.js
const express = require('express');
const router = express.Router();
const { getTaskNotifications, markNotificationsAsRead, streamTaskNotifications } = require('../controllers/taskController');

router.get('/', getTaskNotifications);
router.patch('/mark-read', markNotificationsAsRead);
router.get('/stream', streamTaskNotifications);

module.exports = router;
