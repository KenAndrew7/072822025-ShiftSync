// server/routes/attendanceRoutes.js
const express = require('express');
const router = express.Router();
const { addAttendanceRecord, getAttendanceByEmployee, getAllAttendance, getAttendanceSummary } = require('../controllers/attendanceController');

// GET /api/attendance - Get all attendance records with filtering and pagination
router.get('/', getAllAttendance);

// GET /api/attendance/summary - Get daily attendance totals
router.get('/summary', getAttendanceSummary);

// POST /api/attendance - Add new attendance record
router.post('/', addAttendanceRecord);

// GET /api/attendance/:employee_id - Get all attendance records for employee
router.get('/:employee_id', getAttendanceByEmployee);

module.exports = router;
