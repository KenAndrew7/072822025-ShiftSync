// server/routes/ppsRoutes.js
const express = require('express');
const router = express.Router();
const { getAllPPS, getPPSStatuses, getPPSPriorities, getPPSById, updatePlanStatus, updateWorkOrder, getPPSSummary } = require('../controllers/ppsController');

// GET /api/pps - Get all production planning with filtering and pagination
router.get('/', getAllPPS);

// GET /api/pps/statuses - Get distinct PPS statuses
router.get('/statuses', getPPSStatuses);

// GET /api/pps/priorities - Get distinct PPS priorities
router.get('/priorities', getPPSPriorities);

// GET /api/pps/summary - Get PPS summary counts
router.get('/summary', getPPSSummary);

// PUT /api/pps/:plan_id/status - Update production plan status
router.put('/:plan_id/status', updatePlanStatus);

// PUT /api/pps/:plan_id/work_orders/:wom_id - Update work order status and priority
router.put('/:plan_id/work_orders/:wom_id', updateWorkOrder);

// GET /api/pps/:plan_id - Get single PPS by plan_id with work order details
router.get('/:plan_id', getPPSById);

module.exports = router;
