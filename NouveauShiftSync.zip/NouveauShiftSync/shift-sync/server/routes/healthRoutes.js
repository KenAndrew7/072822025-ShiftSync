// server/routes/healthRoutes.js
const express = require('express');
const router = express.Router();
const { q } = require('../db');

// GET /api/health/db - Database health check
router.get('/db', async (req, res) => {
  try {
    // Simple query to test database connectivity
    await q('SELECT 1');
    res.json({ ok: true });
  } catch (error) {
    console.error('Database health check failed:', error);
    res.status(503).json({ 
      ok: false, 
      error: 'Database connection failed',
      details: error.message 
    });
  }
});

module.exports = router;



