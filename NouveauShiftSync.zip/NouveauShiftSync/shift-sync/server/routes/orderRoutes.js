// server/routes/orderRoutes.js
const express = require('express');
const router = express.Router();
const { getAllOrders, getOrderStatuses, getPaymentStatuses, getOrderById, getOrdersSummary, getOrdersTimeseries, getPaymentBreakdown } = require('../controllers/orderController');

// GET /api/orders - Get all orders with filtering and pagination
router.get('/', getAllOrders);

// GET /api/orders/statuses - Get distinct order statuses
router.get('/statuses', getOrderStatuses);

// GET /api/orders/payment-statuses - Get distinct payment statuses
router.get('/payment-statuses', getPaymentStatuses);

// GET /api/orders/summary - Get orders summary with KPIs
router.get('/summary', getOrdersSummary);

// GET /api/orders/timeseries - Get orders timeseries data
router.get('/timeseries', getOrdersTimeseries);

// GET /api/orders/payment_breakdown - Get payment breakdown data
router.get('/payment_breakdown', getPaymentBreakdown);

// GET /api/orders/:id - Get single order by ID with all details
router.get('/:id', getOrderById);

module.exports = router;
