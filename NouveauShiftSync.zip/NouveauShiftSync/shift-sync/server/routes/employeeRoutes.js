// server/routes/employeeRoutes.js
const express = require('express');
const router = express.Router();
const { getAllEmployees, getDepartments, getPositions, getEmployeeById } = require('../controllers/employeeController');

// GET /api/employees - Get all employees with filtering and pagination
router.get('/', getAllEmployees);

// GET /api/employees/departments - Get distinct departments
router.get('/departments', getDepartments);

// GET /api/employees/positions - Get distinct positions
router.get('/positions', getPositions);

// GET /api/employees/:id - Get single employee by ID with detailed info
router.get('/:id', getEmployeeById);

module.exports = router;
