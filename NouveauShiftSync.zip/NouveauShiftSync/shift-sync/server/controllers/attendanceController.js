// server/controllers/attendanceController.js
const { pool } = require('../db');

// POST /api/attendance - Add new attendance record
const addAttendanceRecord = async (req, res) => {
  try {
    const { employee_id, time_in, time_out } = req.body;

    // Validate required fields
    if (!employee_id || !time_in) {
      return res.status(400).json({ 
        error: 'employee_id and time_in are required' 
      });
    }

    // Validate employee_id is a number
    if (isNaN(parseInt(employee_id))) {
      return res.status(400).json({ 
        error: 'employee_id must be a valid number' 
      });
    }

    // Validate time formats
    if (!isValidDateTime(time_in)) {
      return res.status(400).json({ 
        error: 'time_in must be a valid datetime' 
      });
    }

    if (time_out && !isValidDateTime(time_out)) {
      return res.status(400).json({ 
        error: 'time_out must be a valid datetime' 
      });
    }

    // Validate that time_out is after time_in if provided
    if (time_out && new Date(time_out) <= new Date(time_in)) {
      return res.status(400).json({ 
        error: 'time_out must be after time_in' 
      });
    }

    // Check if employee exists
    const employeeCheck = await pool.query(
      'SELECT employee_id FROM employees WHERE employee_id = $1',
      [parseInt(employee_id)]
    );

    if (employeeCheck.rows.length === 0) {
      return res.status(404).json({ 
        error: 'Employee not found' 
      });
    }

    // Insert attendance record
    const insertQuery = `
      INSERT INTO attendance (employee_id, time_in, time_out)
      VALUES ($1, $2, $3)
      RETURNING attendance_id, employee_id, time_in, time_out
    `;

    const values = [
      parseInt(employee_id),
      time_in,
      time_out || null
    ];

    const result = await pool.query(insertQuery, values);
    const newRecord = result.rows[0];

    // Format the response
    const response = {
      attendance_id: newRecord.attendance_id,
      employee_id: newRecord.employee_id,
      time_in: newRecord.time_in,
      time_out: newRecord.time_out,
      total_hours: newRecord.time_out ? 
        calculateHours(newRecord.time_in, newRecord.time_out) : null
    };

    res.status(201).json(response);

  } catch (err) {
    console.error('Error adding attendance record:', err);
    res.status(500).json({ error: 'Error adding attendance record' });
  }
};

// GET /api/attendance/:employee_id - Get all attendance records for employee
const getAttendanceByEmployee = async (req, res) => {
  try {
    const { employee_id } = req.params;

    // Validate employee_id
    if (!employee_id || isNaN(parseInt(employee_id))) {
      return res.status(400).json({ error: 'Invalid employee ID' });
    }

    const employeeId = parseInt(employee_id);

    // Check if employee exists
    const employeeCheck = await pool.query(
      'SELECT employee_id, first_name, last_name FROM employees WHERE employee_id = $1',
      [employeeId]
    );

    if (employeeCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Employee not found' });
    }

    // Get attendance records with daily totals
    const query = `
      SELECT 
        attendance_id,
        employee_id,
        time_in,
        time_out,
        DATE(time_in) as work_date,
        CASE 
          WHEN time_out IS NOT NULL THEN 
            EXTRACT(EPOCH FROM (time_out - time_in)) / 3600
          ELSE NULL 
        END as hours_worked
      FROM attendance 
      WHERE employee_id = $1 
      ORDER BY time_in DESC
    `;

    const result = await pool.query(query, [employeeId]);
    const records = result.rows;

    // Calculate daily totals
    const dailyTotals = new Map();
    records.forEach(record => {
      const date = record.work_date;
      if (record.hours_worked) {
        const currentTotal = dailyTotals.get(date) || 0;
        dailyTotals.set(date, currentTotal + parseFloat(record.hours_worked));
      }
    });

    // Format records with daily totals
    const formattedRecords = records.map(record => ({
      attendance_id: record.attendance_id,
      employee_id: record.employee_id,
      time_in: record.time_in,
      time_out: record.time_out,
      work_date: record.work_date,
      hours_worked: record.hours_worked ? 
        Math.round(record.hours_worked * 100) / 100 : null,
      daily_total: dailyTotals.get(record.work_date) ? 
        Math.round(dailyTotals.get(record.work_date) * 100) / 100 : null
    }));

    // Convert daily totals map to array for easier frontend consumption
    const dailySummary = Array.from(dailyTotals.entries()).map(([date, hours]) => ({
      date,
      total_hours: Math.round(hours * 100) / 100
    })).sort((a, b) => new Date(b.date) - new Date(a.date));

    res.json({
      employee: employeeCheck.rows[0],
      records: formattedRecords,
      daily_summary: dailySummary,
      total_records: records.length
    });

  } catch (err) {
    console.error('Error fetching attendance records:', err);
    res.status(500).json({ error: 'Error fetching attendance records' });
  }
};

// Helper functions
function isValidDateTime(dateTimeString) {
  if (!dateTimeString) return false;
  const date = new Date(dateTimeString);
  return date instanceof Date && !isNaN(date);
}

function calculateHours(timeIn, timeOut) {
  if (!timeIn || !timeOut) return null;
  const diffMs = new Date(timeOut) - new Date(timeIn);
  const hours = diffMs / (1000 * 60 * 60);
  return Math.round(hours * 100) / 100;
}

// GET /api/attendance - Get all attendance records with filtering and pagination
const getAllAttendance = async (req, res) => {
  try {
    const { 
      employee_id, 
      from, 
      to, 
      page = 1, 
      limit = 10 
    } = req.query;

    // Convert page and limit to numbers
    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const offset = (pageNum - 1) * limitNum;

    // Build the base query
    let query = `
      SELECT 
        a.attendance_id,
        a.employee_id,
        a.time_in,
        a.time_out,
        CASE 
          WHEN a.time_out IS NOT NULL THEN 
            EXTRACT(EPOCH FROM (a.time_out - a.time_in)) / 3600
          ELSE 0 
        END as duration_hours
      FROM attendance a
      WHERE 1=1
    `;

    const queryParams = [];
    let paramCount = 0;

    // Add filters
    if (employee_id) {
      paramCount++;
      query += ` AND a.employee_id = $${paramCount}`;
      queryParams.push(parseInt(employee_id));
    }

    if (from) {
      paramCount++;
      query += ` AND DATE(a.time_in) >= $${paramCount}`;
      queryParams.push(from);
    }

    if (to) {
      paramCount++;
      query += ` AND DATE(a.time_in) <= $${paramCount}`;
      queryParams.push(to);
    }

    // Get total count for pagination (before adding LIMIT/OFFSET)
    const countQuery = `
      SELECT COUNT(*) as total FROM attendance a
      WHERE 1=1
      ${employee_id ? ` AND a.employee_id = ${parseInt(employee_id)}` : ''}
      ${from ? ` AND DATE(a.time_in) >= '${from}'` : ''}
      ${to ? ` AND DATE(a.time_in) <= '${to}'` : ''}
    `;

    // Add ordering and pagination to main query
    query += ` ORDER BY a.time_in DESC`;
    paramCount++;
    query += ` LIMIT $${paramCount}`;
    queryParams.push(limitNum);
    paramCount++;
    query += ` OFFSET $${paramCount}`;
    queryParams.push(offset);

    // Execute both queries
    const [attendanceResult, countResult] = await Promise.all([
      pool.query(query, queryParams),
      pool.query(countQuery)
    ]);

    const total = parseInt(countResult.rows[0].total);
    const totalPages = Math.ceil(total / limitNum);

    // Format the response
    const formattedAttendance = attendanceResult.rows.map(record => ({
      attendance_id: record.attendance_id,
      employee_id: record.employee_id,
      time_in: record.time_in,
      time_out: record.time_out,
      duration_hours: record.duration_hours ? 
        Math.round(record.duration_hours * 100) / 100 : 0
    }));

    res.json({
      items: formattedAttendance,
      page: pageNum,
      limit: limitNum,
      total: total,
      totalPages: totalPages
    });

  } catch (err) {
    console.error('Error fetching attendance:', err);
    res.status(500).json({ error: 'Error fetching attendance records' });
  }
};

// GET /api/attendance/summary - Get daily attendance totals with KPIs
const getAttendanceSummary = async (req, res) => {
  try {
    const { employee_id, from, to } = req.query;

    // Build the base query for daily totals
    let query = `
      SELECT 
        DATE(a.time_in) as date,
        COALESCE(
          SUM(
            CASE 
              WHEN a.time_out IS NOT NULL THEN 
                EXTRACT(EPOCH FROM (a.time_out - a.time_in)) / 3600
              ELSE 0 
            END
          ), 
          0
        ) as total_hours
      FROM attendance a
      WHERE 1=1
    `;

    const queryParams = [];
    let paramCount = 0;

    // Add filters
    if (employee_id) {
      paramCount++;
      query += ` AND a.employee_id = $${paramCount}`;
      queryParams.push(parseInt(employee_id));
    }

    if (from) {
      paramCount++;
      query += ` AND DATE(a.time_in) >= $${paramCount}`;
      queryParams.push(from);
    }

    if (to) {
      paramCount++;
      query += ` AND DATE(a.time_in) <= $${paramCount}`;
      queryParams.push(to);
    }

    // Group by date and order by date descending
    query += ` GROUP BY DATE(a.time_in) ORDER BY DATE(a.time_in) DESC`;

    const result = await pool.query(query, queryParams);

    // Format daily totals
    const dailyTotals = result.rows.map(row => ({
      date: row.date.toISOString().split('T')[0], // Format as YYYY-MM-DD
      total_hours: Math.round(parseFloat(row.total_hours) * 100) / 100 // Round to 2 decimal places
    }));

    // Calculate KPIs
    const totalHoursRange = dailyTotals.reduce((sum, day) => sum + day.total_hours, 0);
    const activeDaysCount = dailyTotals.filter(day => day.total_hours > 0).length;
    const avgHoursPerDay = activeDaysCount > 0 ? totalHoursRange / activeDaysCount : 0;

    // Format the response with KPIs and daily data
    const response = {
      total_hours_range: Math.round(totalHoursRange * 100) / 100,
      avg_hours_per_day: Math.round(avgHoursPerDay * 100) / 100,
      active_days_count: activeDaysCount,
      daily: dailyTotals
    };

    res.json(response);

  } catch (err) {
    console.error('Error fetching attendance summary:', err);
    res.status(500).json({ error: 'Error fetching attendance summary' });
  }
};

module.exports = {
  addAttendanceRecord,
  getAttendanceByEmployee,
  getAllAttendance,
  getAttendanceSummary
};
