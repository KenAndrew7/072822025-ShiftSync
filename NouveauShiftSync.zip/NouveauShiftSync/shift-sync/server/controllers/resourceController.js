// server/controllers/resourceController.js
const { q } = require('../db');

const getAllResources = async (req, res) => {
  try {
    const rows = (await q('SELECT * FROM resource_allocation')).rows;
    res.json(rows);
  } catch (err) {
    console.error('Error fetching resource allocation:', err);
    res.status(500).json({ error: 'Error fetching resource allocation' });
  }
};

module.exports = {
  getAllResources,
};