// server/controllers/orderController.js
const { pool } = require('../db');

const getAllOrders = async (req, res) => {
  try {
    const { 
      status, 
      payment_status, 
      date_from, 
      date_to, 
      q, 
      page = 1, 
      limit = 10 
    } = req.query;

    // Convert page and limit to numbers
    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const offset = (pageNum - 1) * limitNum;

    // Build the base query
    let query = `
      SELECT 
        order_id,
        order_date,
        customer_id,
        product_id,
        product_name,
        quantity,
        total_amount,
        order_status,
        payment_status,
        payment_method,
        business_id
      FROM sales_orders
      WHERE order_status != 'canceled'
    `;

    const queryParams = [];
    let paramCount = 0;

    // Add filters
    if (status) {
      paramCount++;
      query += ` AND order_status = $${paramCount}`;
      queryParams.push(status);
    }

    if (payment_status) {
      paramCount++;
      query += ` AND payment_status = $${paramCount}`;
      queryParams.push(payment_status);
    }

    if (date_from) {
      paramCount++;
      query += ` AND order_date >= $${paramCount}`;
      queryParams.push(date_from);
    }

    if (date_to) {
      paramCount++;
      query += ` AND order_date <= $${paramCount}`;
      queryParams.push(date_to);
    }

    if (q) {
      paramCount++;
      query += ` AND product_name ILIKE $${paramCount}`;
      queryParams.push(`%${q}%`);
    }

    // Get total count for pagination (before adding LIMIT/OFFSET)
    const countQuery = query.replace(
      'SELECT order_id, order_date, customer_id, product_id, product_name, quantity, total_amount, order_status, payment_status, payment_method, business_id',
      'SELECT COUNT(*) as total'
    );

    // Add ordering and pagination to main query
    query += ` ORDER BY order_date DESC, order_id DESC`;
    paramCount++;
    query += ` LIMIT $${paramCount}`;
    queryParams.push(limitNum);
    paramCount++;
    query += ` OFFSET $${paramCount}`;
    queryParams.push(offset);

    // Execute both queries
    const [ordersResult, countResult] = await Promise.all([
      pool.query(query, queryParams),
      pool.query(countQuery, queryParams.slice(0, -2)) // Remove LIMIT and OFFSET params for count
    ]);

    const total = parseInt(countResult.rows[0].total);
    const totalPages = Math.ceil(total / limitNum);

    // Format the response
    const formattedOrders = ordersResult.rows.map(order => ({
      order_id: order.order_id,
      order_date: order.order_date,
      customer_id: order.customer_id,
      product_id: order.product_id,
      product_name: order.product_name,
      quantity: order.quantity,
      total_amount: parseFloat(order.total_amount || 0),
      order_status: order.order_status,
      payment_status: order.payment_status,
      payment_method: order.payment_method,
      business_id: order.business_id
    }));

    res.json({
      items: formattedOrders,
      page: pageNum,
      limit: limitNum,
      total: total,
      totalPages: totalPages
    });

  } catch (err) {
    console.error('Error fetching orders:', err);
    res.status(500).json({ error: 'Error fetching orders' });
  }
};

// Get distinct order statuses for filter dropdown
const getOrderStatuses = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT DISTINCT order_status 
      FROM sales_orders 
      WHERE order_status != 'canceled' AND order_status IS NOT NULL 
      ORDER BY order_status
    `);
    res.json(result.rows.map(row => row.order_status));
  } catch (err) {
    console.error('Error fetching order statuses:', err);
    res.status(500).json({ error: 'Error fetching order statuses' });
  }
};

// Get distinct payment statuses for filter dropdown
const getPaymentStatuses = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT DISTINCT payment_status 
      FROM sales_orders 
      WHERE order_status != 'canceled' AND payment_status IS NOT NULL 
      ORDER BY payment_status
    `);
    res.json(result.rows.map(row => row.payment_status));
  } catch (err) {
    console.error('Error fetching payment statuses:', err);
    res.status(500).json({ error: 'Error fetching payment statuses' });
  }
};

// Get single order by ID with all details
const getOrderById = async (req, res) => {
  try {
    const { id } = req.params;
    
    // Validate order ID
    if (!id || isNaN(parseInt(id))) {
      return res.status(400).json({ error: 'Invalid order ID' });
    }

    const orderId = parseInt(id);

    // Query to get complete order details
    const query = `
      SELECT 
        order_id,
        customer_id,
        order_date,
        total_amount,
        order_status,
        payment_status,
        payment_method,
        shipping_address,
        created_by,
        updated_at,
        quantity,
        product_id,
        product_name,
        items,
        business_id
      FROM sales_orders
      WHERE order_id = $1
    `;

    const result = await pool.query(query, [orderId]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Order not found' });
    }

    const order = result.rows[0];
    
    // Format the response
    const response = {
      order_id: order.order_id,
      customer_id: order.customer_id,
      order_date: order.order_date,
      total_amount: parseFloat(order.total_amount || 0),
      order_status: order.order_status,
      payment_status: order.payment_status,
      payment_method: order.payment_method,
      shipping_address: order.shipping_address,
      created_by: order.created_by,
      updated_at: order.updated_at,
      quantity: order.quantity,
      product_id: order.product_id,
      product_name: order.product_name,
      items: order.items || [],
      business_id: order.business_id
    };

    res.json(response);

  } catch (err) {
    console.error('Error fetching order by ID:', err);
    res.status(500).json({ error: 'Error fetching order details' });
  }
};

// Get orders summary with KPIs
const getOrdersSummary = async (req, res) => {
  try {
    const { from, to } = req.query;
    
    // Set default date range if not provided
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const endDate = to ? new Date(to) : new Date(today);
    endDate.setHours(23, 59, 59, 999);
    
    // Default to last 30 days if no from date
    const startDate = from ? new Date(from) : new Date(today.getTime() - (30 * 24 * 60 * 60 * 1000));
    startDate.setHours(0, 0, 0, 0);

    // Get today's date boundaries
    const todayStart = new Date(today);
    const todayEnd = new Date(today);
    todayEnd.setHours(23, 59, 59, 999);

    // Get current month boundaries
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
    const monthEnd = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    monthEnd.setHours(23, 59, 59, 999);

    // Query for orders today
    const todayQuery = `
      SELECT 
        COUNT(*) as orders_count,
        COALESCE(SUM(total_amount), 0) as revenue
      FROM sales_orders 
      WHERE order_status != 'canceled' 
        AND order_date >= $1 AND order_date <= $2
    `;

    // Query for orders this month
    const monthQuery = `
      SELECT 
        COUNT(*) as orders_count,
        COALESCE(SUM(total_amount), 0) as revenue,
        COALESCE(AVG(total_amount), 0) as avg_order_value
      FROM sales_orders 
      WHERE order_status != 'canceled' 
        AND order_date >= $1 AND order_date <= $2
    `;

    // Query for unpaid orders count
    const unpaidQuery = `
      SELECT COUNT(*) as unpaid_count
      FROM sales_orders 
      WHERE order_status != 'canceled' 
        AND payment_status != 'paid'
        AND order_date >= $1 AND order_date <= $2
    `;

    // Query for paid vs unpaid breakdown
    const paidVsUnpaidQuery = `
      SELECT 
        payment_status,
        COUNT(*) as count
      FROM sales_orders 
      WHERE order_status != 'canceled' 
        AND order_date >= $1 AND order_date <= $2
      GROUP BY payment_status
    `;

    // Execute all queries
    const [todayResult, monthResult, unpaidResult, paidVsUnpaidResult] = await Promise.all([
      pool.query(todayQuery, [todayStart, todayEnd]),
      pool.query(monthQuery, [monthStart, monthEnd]),
      pool.query(unpaidQuery, [monthStart, monthEnd]),
      pool.query(paidVsUnpaidQuery, [monthStart, monthEnd])
    ]);

    // Process results
    const todayData = todayResult.rows[0];
    const monthData = monthResult.rows[0];
    const unpaidData = unpaidResult.rows[0];
    
    // Process paid vs unpaid data
    const paidVsUnpaid = { paid: 0, unpaid: 0 };
    paidVsUnpaidResult.rows.forEach(row => {
      if (row.payment_status === 'paid') {
        paidVsUnpaid.paid = parseInt(row.count);
      } else {
        paidVsUnpaid.unpaid += parseInt(row.count);
      }
    });

    // Format response
    const summary = {
      orders_today: parseInt(todayData.orders_count) || 0,
      revenue_today: parseFloat(todayData.revenue) || 0,
      orders_this_month: parseInt(monthData.orders_count) || 0,
      revenue_this_month: parseFloat(monthData.revenue) || 0,
      avg_order_value_this_month: parseFloat(monthData.avg_order_value) || 0,
      unpaid_orders_count: parseInt(unpaidData.unpaid_count) || 0,
      paid_vs_unpaid: paidVsUnpaid,
      date_range: {
        from: monthStart.toISOString().split('T')[0],
        to: monthEnd.toISOString().split('T')[0]
      }
    };

    res.json(summary);

  } catch (err) {
    console.error('Error fetching orders summary:', err);
    res.status(500).json({ error: 'Error fetching orders summary' });
  }
};

// Get orders timeseries data
const getOrdersTimeseries = async (req, res) => {
  try {
    const { from, to, interval = 'day' } = req.query;
    
    // Set default date range (last 14 days for dashboard)
    const today = new Date();
    const endDate = to ? new Date(to) : new Date(today);
    endDate.setHours(23, 59, 59, 999);
    
    const startDate = from ? new Date(from) : new Date(today.getTime() - (14 * 24 * 60 * 60 * 1000));
    startDate.setHours(0, 0, 0, 0);

    // Validate interval
    if (!['day', 'month'].includes(interval)) {
      return res.status(400).json({ error: 'Invalid interval. Must be "day" or "month"' });
    }

    // Build query based on interval
    let dateFormat, dateGroup;
    if (interval === 'day') {
      dateFormat = 'YYYY-MM-DD';
      dateGroup = 'DATE(order_date)';
    } else {
      dateFormat = 'YYYY-MM';
      dateGroup = 'DATE_TRUNC(\'month\', order_date)';
    }

    const query = `
      SELECT 
        TO_CHAR(${dateGroup}, '${dateFormat}') as date,
        COALESCE(SUM(total_amount), 0) as total_revenue,
        COUNT(*) as total_orders
      FROM sales_orders 
      WHERE order_status != 'canceled' 
        AND order_date >= $1 AND order_date <= $2
      GROUP BY ${dateGroup}
      ORDER BY ${dateGroup}
    `;

    const result = await pool.query(query, [startDate, endDate]);

    // Fill in missing dates with zero values
    const timeseriesData = [];
    const currentDate = new Date(startDate);
    
    while (currentDate <= endDate) {
      const dateStr = interval === 'day' 
        ? currentDate.toISOString().split('T')[0]
        : currentDate.toISOString().slice(0, 7);
      
      const existingData = result.rows.find(row => row.date === dateStr);
      
      timeseriesData.push({
        date: dateStr,
        total_revenue: existingData ? parseFloat(existingData.total_revenue) : 0,
        total_orders: existingData ? parseInt(existingData.total_orders) : 0
      });

      // Increment date
      if (interval === 'day') {
        currentDate.setDate(currentDate.getDate() + 1);
      } else {
        currentDate.setMonth(currentDate.getMonth() + 1);
      }
    }

    // Limit to 14 points max for dashboard charts
    const limitedData = timeseriesData.slice(-14);
    
    res.json(limitedData);

  } catch (err) {
    console.error('Error fetching orders timeseries:', err);
    res.status(500).json({ error: 'Error fetching orders timeseries' });
  }
};

// Get payment breakdown data
const getPaymentBreakdown = async (req, res) => {
  try {
    const { from, to } = req.query;
    
    // Set default date range (current month)
    const today = new Date();
    const endDate = to ? new Date(to) : new Date(today);
    endDate.setHours(23, 59, 59, 999);
    
    const startDate = from ? new Date(from) : new Date(today.getFullYear(), today.getMonth(), 1);
    startDate.setHours(0, 0, 0, 0);

    const query = `
      SELECT 
        CASE 
          WHEN payment_status = 'paid' THEN 'paid'
          ELSE 'unpaid'
        END as status,
        COUNT(*) as count,
        COALESCE(SUM(total_amount), 0) as total_amount
      FROM sales_orders 
      WHERE order_status != 'canceled' 
        AND order_date >= $1 AND order_date <= $2
      GROUP BY CASE WHEN payment_status = 'paid' THEN 'paid' ELSE 'unpaid' END
      ORDER BY status
    `;

    const result = await pool.query(query, [startDate, endDate]);

    // Format response with default values
    const breakdown = {
      paid: 0,
      unpaid: 0
    };

    result.rows.forEach(row => {
      breakdown[row.status] = {
        count: parseInt(row.count),
        total_amount: parseFloat(row.total_amount)
      };
    });

    // Ensure both paid and unpaid exist with default values
    if (typeof breakdown.paid === 'number') {
      breakdown.paid = { count: 0, total_amount: 0 };
    }
    if (typeof breakdown.unpaid === 'number') {
      breakdown.unpaid = { count: 0, total_amount: 0 };
    }

    res.json(breakdown);

  } catch (err) {
    console.error('Error fetching payment breakdown:', err);
    res.status(500).json({ error: 'Error fetching payment breakdown' });
  }
};

module.exports = {
  getAllOrders,
  getOrderStatuses,
  getPaymentStatuses,
  getOrderById,
  getOrdersSummary,
  getOrdersTimeseries,
  getPaymentBreakdown
};
