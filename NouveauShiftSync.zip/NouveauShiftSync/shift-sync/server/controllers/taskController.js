// server/controllers/taskController.js
const { pool } = require('../db');

const getAllTasks = async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM tasks');
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching tasks');
  }
};

const notifyTaskUpdate = async (req, res) => {
  try {
    const { id } = req.params;
    const { message, department, actor } = req.body;

    // Validate task ID
    if (!id || isNaN(parseInt(id))) {
      return res.status(400).json({ error: 'Invalid task ID' });
    }

    const taskId = parseInt(id);
    let taskDepartment = department;

    // Look up task's department if not provided
    if (!taskDepartment) {
      const taskQuery = 'SELECT department FROM tasks WHERE id = $1';
      const taskResult = await pool.query(taskQuery, [taskId]);
      
      if (taskResult.rows.length === 0) {
        return res.status(404).json({ error: 'Task not found' });
      }
      
      taskDepartment = taskResult.rows[0].department;
    }

    // Create default message if not provided
    const notificationMessage = message || `Task #${taskId} updated by ${actor || 'Admin'}.`;

    // Insert notification into task_notifications table
    const insertQuery = `
      INSERT INTO task_notifications (task_id, department, message, created_at) 
      VALUES ($1, $2, $3, NOW())
      RETURNING *
    `;
    
    const result = await pool.query(insertQuery, [taskId, taskDepartment, notificationMessage]);

    // Broadcast to SSE clients if insertion was successful
    if (result.rows.length > 0) {
      const newNotification = result.rows[0];
      broadcastNotification(newNotification);
    }

    res.json({ ok: true });
  } catch (err) {
    console.error('Error creating task notification:', err);
    res.status(500).json({ error: 'Error creating task notification' });
  }
};

const getTaskNotifications = async (req, res) => {
  try {
    const { department, limit = 20 } = req.query;

    // Convert limit to number
    const limitNum = parseInt(limit) || 20;

    // Build query with optional department filter
    let query = `
      SELECT 
        id,
        task_id,
        department,
        message,
        read,
        created_at
      FROM task_notifications
    `;
    
    const queryParams = [];
    let paramCount = 0;

    // Add department filter if provided
    if (department) {
      paramCount++;
      query += ` WHERE department = $${paramCount}`;
      queryParams.push(department);
    }

    // Add ordering and limit
    query += ` ORDER BY created_at DESC`;
    paramCount++;
    query += ` LIMIT $${paramCount}`;
    queryParams.push(limitNum);

    const result = await pool.query(query, queryParams);
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching task notifications:', err);
    res.status(500).json({ error: 'Error fetching task notifications' });
  }
};

// Helper function to insert automatic task notification
const insertTaskNotification = async (taskId, department, message) => {
  try {
    const insertQuery = `
      INSERT INTO task_notifications (task_id, department, message, created_at) 
      VALUES ($1, $2, $3, NOW())
      RETURNING *
    `;
    const result = await pool.query(insertQuery, [taskId, department, message]);
    
    // Broadcast to SSE clients if insertion was successful
    if (result.rows.length > 0) {
      const newNotification = result.rows[0];
      broadcastNotification(newNotification);
    }
  } catch (err) {
    console.error('Error inserting automatic task notification:', err);
    // Don't throw - we don't want notification failures to break the main operation
  }
};

// Update task status
const updateTaskStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    // Validate task ID
    if (!id || isNaN(parseInt(id))) {
      return res.status(400).json({ error: 'Invalid task ID' });
    }

    // Validate status
    if (!status) {
      return res.status(400).json({ error: 'Status is required' });
    }

    const taskId = parseInt(id);

    // Get current task to check if it exists and get department
    const currentTaskQuery = 'SELECT id, status, department FROM tasks WHERE id = $1';
    const currentTaskResult = await pool.query(currentTaskQuery, [taskId]);

    if (currentTaskResult.rows.length === 0) {
      return res.status(404).json({ error: 'Task not found' });
    }

    const currentTask = currentTaskResult.rows[0];
    const oldStatus = currentTask.status;

    // Only update if status actually changed
    if (oldStatus === status) {
      return res.json(currentTask);
    }

    // Update the task status
    const updateQuery = `
      UPDATE tasks 
      SET status = $1, updated_at = NOW()
      WHERE id = $2 
      RETURNING *
    `;

    const result = await pool.query(updateQuery, [status, taskId]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Task not found' });
    }

    const updatedTask = result.rows[0];

    // Insert automatic notification for status change
    const notificationMessage = `Task #${taskId} status changed to '${status}'.`;
    await insertTaskNotification(taskId, updatedTask.department, notificationMessage);

    res.json(updatedTask);
  } catch (err) {
    console.error('Error updating task status:', err);
    res.status(500).json({ error: 'Error updating task status' });
  }
};

// Mark notifications as read
const markNotificationsAsRead = async (req, res) => {
  try {
    const { ids } = req.body;

    // Validate that ids is an array
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: 'ids must be a non-empty array' });
    }

    // Validate all ids are numbers
    const validIds = ids.filter(id => !isNaN(parseInt(id))).map(id => parseInt(id));
    if (validIds.length === 0) {
      return res.status(400).json({ error: 'No valid notification IDs provided' });
    }

    // Create placeholders for parameterized query
    const placeholders = validIds.map((_, index) => `$${index + 1}`).join(',');
    
    const updateQuery = `
      UPDATE task_notifications 
      SET read = true 
      WHERE id IN (${placeholders})
      RETURNING id
    `;

    const result = await pool.query(updateQuery, validIds);

    res.json({ 
      ok: true, 
      updated_count: result.rows.length,
      updated_ids: result.rows.map(row => row.id)
    });
  } catch (err) {
    console.error('Error marking notifications as read:', err);
    res.status(500).json({ error: 'Error marking notifications as read' });
  }
};

// Store SSE connections by department
const sseConnections = new Map();

// SSE endpoint for real-time notifications
const streamTaskNotifications = (req, res) => {
  const { department } = req.query;
  
  if (!department) {
    return res.status(400).json({ error: 'Department parameter is required' });
  }

  // Set SSE headers
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Cache-Control'
  });

  // Send initial connection message
  res.write(`data: ${JSON.stringify({ type: 'connected', message: 'SSE connection established' })}\n\n`);

  // Store connection
  if (!sseConnections.has(department)) {
    sseConnections.set(department, new Set());
  }
  sseConnections.get(department).add(res);

  // Handle client disconnect
  req.on('close', () => {
    const departmentConnections = sseConnections.get(department);
    if (departmentConnections) {
      departmentConnections.delete(res);
      if (departmentConnections.size === 0) {
        sseConnections.delete(department);
      }
    }
  });

  // Keep connection alive with periodic heartbeat
  const heartbeat = setInterval(() => {
    try {
      res.write(`data: ${JSON.stringify({ type: 'heartbeat', timestamp: Date.now() })}\n\n`);
    } catch (error) {
      clearInterval(heartbeat);
      const departmentConnections = sseConnections.get(department);
      if (departmentConnections) {
        departmentConnections.delete(res);
      }
    }
  }, 30000); // Send heartbeat every 30 seconds

  req.on('close', () => {
    clearInterval(heartbeat);
  });
};

// Function to broadcast notification to SSE clients
const broadcastNotification = (notification) => {
  const department = notification.department;
  const departmentConnections = sseConnections.get(department);
  
  if (departmentConnections && departmentConnections.size > 0) {
    const eventData = JSON.stringify({
      type: 'notification',
      data: notification
    });

    // Send to all connections for this department
    for (const connection of departmentConnections) {
      try {
        connection.write(`data: ${eventData}\n\n`);
      } catch (error) {
        // Remove failed connection
        departmentConnections.delete(connection);
      }
    }
  }
};

module.exports = {
  getAllTasks,
  notifyTaskUpdate,
  getTaskNotifications,
  updateTaskStatus,
  markNotificationsAsRead,
  streamTaskNotifications,
  broadcastNotification,
};
