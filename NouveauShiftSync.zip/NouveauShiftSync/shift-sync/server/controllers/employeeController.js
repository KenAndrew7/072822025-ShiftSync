// server/controllers/employeeController.js
const { pool } = require('../db');

const getAllEmployees = async (req, res) => {
  try {
    const { 
      department, 
      position, 
      search, 
      page = 1, 
      limit = 10 
    } = req.query;

    // Convert page and limit to numbers
    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const offset = (pageNum - 1) * limitNum;

    // Build the base query with joins
    let query = `
      SELECT 
        e.employee_id,
        CONCAT(e.first_name, ' ', e.middle_name, ' ', e.last_name) as full_name,
        e.department,
        e.position,
        e.email,
        e.phone,
        es.job_title,
        es.hourly_rate
      FROM employees e
      LEFT JOIN employee_salary es ON e.employee_id = es.employee_id
      WHERE 1=1
    `;

    const queryParams = [];
    let paramCount = 0;

    // Add filters
    if (department) {
      paramCount++;
      query += ` AND e.department ILIKE $${paramCount}`;
      queryParams.push(`%${department}%`);
    }

    if (position) {
      paramCount++;
      query += ` AND e.position ILIKE $${paramCount}`;
      queryParams.push(`%${position}%`);
    }

    if (search) {
      paramCount++;
      query += ` AND (
        e.first_name ILIKE $${paramCount} OR 
        e.middle_name ILIKE $${paramCount} OR 
        e.last_name ILIKE $${paramCount} OR
        CONCAT(e.first_name, ' ', e.middle_name, ' ', e.last_name) ILIKE $${paramCount}
      )`;
      queryParams.push(`%${search}%`);
    }

    // Get total count for pagination
    const countQuery = `
      SELECT COUNT(DISTINCT e.employee_id) as total
      FROM employees e
      LEFT JOIN employee_salary es ON e.employee_id = es.employee_id
      WHERE 1=1
      ${department ? `AND e.department ILIKE '%${department}%'` : ''}
      ${position ? `AND e.position ILIKE '%${position}%'` : ''}
      ${search ? `AND (
        e.first_name ILIKE '%${search}%' OR 
        e.middle_name ILIKE '%${search}%' OR 
        e.last_name ILIKE '%${search}%' OR
        CONCAT(e.first_name, ' ', e.middle_name, ' ', e.last_name) ILIKE '%${search}%'
      )` : ''}
    `;

    // Add ordering and pagination
    query += ` ORDER BY e.last_name, e.first_name`;
    paramCount++;
    query += ` LIMIT $${paramCount}`;
    queryParams.push(limitNum);
    paramCount++;
    query += ` OFFSET $${paramCount}`;
    queryParams.push(offset);

    // Execute both queries
    const [employeesResult, countResult] = await Promise.all([
      pool.query(query, queryParams),
      pool.query(countQuery)
    ]);

    const total = parseInt(countResult.rows[0].total);
    const totalPages = Math.ceil(total / limitNum);

    res.json({
      items: employeesResult.rows,
      page: pageNum,
      limit: limitNum,
      total: total,
      totalPages: totalPages
    });

  } catch (err) {
    console.error('Error fetching employees:', err);
    res.status(500).json({ error: 'Error fetching employees' });
  }
};

// Get distinct departments for filter dropdown
const getDepartments = async (req, res) => {
  try {
    const result = await pool.query('SELECT DISTINCT department FROM employees WHERE department IS NOT NULL ORDER BY department');
    res.json(result.rows.map(row => row.department));
  } catch (err) {
    console.error('Error fetching departments:', err);
    res.status(500).json({ error: 'Error fetching departments' });
  }
};

// Get distinct positions for filter dropdown
const getPositions = async (req, res) => {
  try {
    const result = await pool.query('SELECT DISTINCT position FROM employees WHERE position IS NOT NULL ORDER BY position');
    res.json(result.rows.map(row => row.position));
  } catch (err) {
    console.error('Error fetching positions:', err);
    res.status(500).json({ error: 'Error fetching positions' });
  }
};

// Get single employee by ID with detailed info
const getEmployeeById = async (req, res) => {
  try {
    const { id } = req.params;
    
    // Validate employee ID
    if (!id || isNaN(parseInt(id))) {
      return res.status(400).json({ error: 'Invalid employee ID' });
    }

    const employeeId = parseInt(id);

    // Query to get employee details with salary info and monthly hours
    const query = `
      SELECT 
        e.employee_id,
        CONCAT(e.first_name, ' ', e.middle_name, ' ', e.last_name) as full_name,
        e.department,
        e.position,
        e.email,
        e.phone,
        es.job_title,
        es.hourly_rate,
        COALESCE(
          EXTRACT(EPOCH FROM SUM(a.time_out - a.time_in)) / 3600, 
          0
        ) as total_monthly_hours
      FROM employees e
      LEFT JOIN employee_salary es ON e.employee_id = es.employee_id
      LEFT JOIN attendance a ON e.employee_id = a.employee_id 
        AND EXTRACT(YEAR FROM a.time_in) = EXTRACT(YEAR FROM CURRENT_DATE)
        AND EXTRACT(MONTH FROM a.time_in) = EXTRACT(MONTH FROM CURRENT_DATE)
        AND a.time_out IS NOT NULL
      WHERE e.employee_id = $1
      GROUP BY e.employee_id, e.first_name, e.middle_name, e.last_name, 
               e.department, e.position, e.email, e.phone, es.job_title, es.hourly_rate
    `;

    const result = await pool.query(query, [employeeId]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Employee not found' });
    }

    const employee = result.rows[0];
    
    // Round the hours to 2 decimal places
    employee.total_monthly_hours = Math.round(employee.total_monthly_hours * 100) / 100;

    res.json(employee);

  } catch (err) {
    console.error('Error fetching employee by ID:', err);
    res.status(500).json({ error: 'Error fetching employee details' });
  }
};

module.exports = {
  getAllEmployees,
  getDepartments,
  getPositions,
  getEmployeeById
};
