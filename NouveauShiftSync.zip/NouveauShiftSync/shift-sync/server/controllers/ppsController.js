// server/controllers/ppsController.js
const { pool } = require('../db');

const getAllPPS = async (req, res) => {
  try {
    const { 
      status, 
      priority, 
      date_from, 
      date_to, 
      q, 
      page = 1, 
      limit = 10 
    } = req.query;

    // Convert page and limit to numbers
    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const offset = (pageNum - 1) * limitNum;

    // Build the base query with joins and grouping
    let query = `
      SELECT 
        pp.plan_id,
        pp.order_id,
        pp.customer_id,
        pp.product_id,
        pp.product_name,
        pp.work_order_id,
        pp.planned_date,
        pp.status,
        pp.quantity,
        CASE 
          WHEN bool_or(wom.priority = 'high') THEN 'high'
          ELSE 'low'
        END as priority
      FROM production_planning pp
      LEFT JOIN work_order_management wom ON pp.plan_id = wom.plan_id
      WHERE 1=1
    `;

    const queryParams = [];
    let paramCount = 0;

    // Add filters
    if (status) {
      paramCount++;
      query += ` AND pp.status = $${paramCount}`;
      queryParams.push(status);
    }

    if (date_from) {
      paramCount++;
      query += ` AND pp.planned_date >= $${paramCount}`;
      queryParams.push(date_from);
    }

    if (date_to) {
      paramCount++;
      query += ` AND pp.planned_date <= $${paramCount}`;
      queryParams.push(date_to);
    }

    if (q) {
      paramCount++;
      query += ` AND (pp.product_name ILIKE $${paramCount} OR wom.task_description ILIKE $${paramCount})`;
      queryParams.push(`%${q}%`);
    }

    // Add GROUP BY clause
    query += ` 
      GROUP BY pp.plan_id, pp.order_id, pp.customer_id, pp.product_id, 
               pp.product_name, pp.work_order_id, pp.planned_date, pp.status, pp.quantity
    `;

    // Apply priority filter after grouping if needed
    if (priority) {
      query += ` HAVING CASE 
        WHEN bool_or(wom.priority = 'high') THEN 'high'
        ELSE 'low'
      END = '${priority}'`;
    }

    // Get total count for pagination (before adding LIMIT/OFFSET)
    const countQuery = `
      SELECT COUNT(*) as total FROM (
        ${query}
      ) as grouped_results
    `;

    // Add ordering and pagination to main query
    query += ` ORDER BY pp.planned_date DESC, pp.plan_id DESC`;
    paramCount++;
    query += ` LIMIT $${paramCount}`;
    queryParams.push(limitNum);
    paramCount++;
    query += ` OFFSET $${paramCount}`;
    queryParams.push(offset);

    // Execute both queries
    const [ppsResult, countResult] = await Promise.all([
      pool.query(query, queryParams),
      pool.query(countQuery, queryParams.slice(0, -2)) // Remove LIMIT and OFFSET params for count
    ]);

    const total = parseInt(countResult.rows[0].total);
    const totalPages = Math.ceil(total / limitNum);

    // Format the response
    const formattedPPS = ppsResult.rows.map(pps => ({
      plan_id: pps.plan_id,
      order_id: pps.order_id,
      customer_id: pps.customer_id,
      product_id: pps.product_id,
      product_name: pps.product_name,
      work_order_id: pps.work_order_id,
      planned_date: pps.planned_date,
      status: pps.status,
      quantity: parseInt(pps.quantity || 0),
      priority: pps.priority || 'low'
    }));

    res.json({
      items: formattedPPS,
      page: pageNum,
      limit: limitNum,
      total: total,
      totalPages: totalPages
    });

  } catch (err) {
    console.error('Error fetching PPS:', err);
    res.status(500).json({ error: 'Error fetching production planning data' });
  }
};

// Get distinct statuses for filter dropdown
const getPPSStatuses = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT DISTINCT status 
      FROM production_planning 
      WHERE status IS NOT NULL 
      ORDER BY status
    `);
    res.json(result.rows.map(row => row.status));
  } catch (err) {
    console.error('Error fetching PPS statuses:', err);
    res.status(500).json({ error: 'Error fetching PPS statuses' });
  }
};

// Get distinct priorities for filter dropdown
const getPPSPriorities = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT DISTINCT priority 
      FROM work_order_management 
      WHERE priority IS NOT NULL 
      ORDER BY priority
    `);
    res.json(result.rows.map(row => row.priority));
  } catch (err) {
    console.error('Error fetching PPS priorities:', err);
    res.status(500).json({ error: 'Error fetching PPS priorities' });
  }
};

// Get single PPS by plan_id with work order details
const getPPSById = async (req, res) => {
  try {
    const { plan_id } = req.params;
    
    // Validate plan_id
    if (!plan_id || isNaN(parseInt(plan_id))) {
      return res.status(400).json({ error: 'Invalid plan ID' });
    }

    const planId = parseInt(plan_id);

    // Query to get PPS details with work orders
    const query = `
      SELECT 
        pp.plan_id,
        pp.order_id,
        pp.customer_id,
        pp.product_id,
        pp.product_name,
        pp.work_order_id,
        pp.planned_date,
        pp.status as plan_status,
        pp.quantity as plan_quantity,
        wom.wom_id,
        wom.status as work_order_status,
        wom.priority,
        wom.task_description,
        wom.assigned_to,
        wom.quantity as work_order_quantity,
        wom.employee_id,
        wom.first_name,
        wom.middle_name,
        wom.last_name,
        wom.department
      FROM production_planning pp
      LEFT JOIN work_order_management wom ON pp.plan_id = wom.plan_id
      WHERE pp.plan_id = $1
      ORDER BY wom.priority DESC, wom.wom_id
    `;

    const result = await pool.query(query, [planId]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Production plan not found' });
    }

    // Group the results
    const mainRecord = result.rows[0];
    const workOrders = result.rows
      .filter(row => row.wom_id !== null)
      .map(row => ({
        wom_id: row.wom_id,
        status: row.work_order_status,
        priority: row.priority,
        task_description: row.task_description,
        quantity: parseInt(row.work_order_quantity || 0),
        employee_id: row.employee_id,
        first_name: row.first_name,
        middle_name: row.middle_name,
        last_name: row.last_name,
        department: row.department
      }));

    const response = {
      plan_id: mainRecord.plan_id,
      order_id: mainRecord.order_id,
      customer_id: mainRecord.customer_id,
      product_id: mainRecord.product_id,
      product_name: mainRecord.product_name,
      work_order_id: mainRecord.work_order_id,
      planned_date: mainRecord.planned_date,
      status: mainRecord.plan_status,
      quantity: parseInt(mainRecord.plan_quantity || 0),
      work_orders: workOrders
    };

    res.json(response);

  } catch (err) {
    console.error('Error fetching PPS by ID:', err);
    res.status(500).json({ error: 'Error fetching production plan details' });
  }
};

// Update production plan status
const updatePlanStatus = async (req, res) => {
  try {
    const { plan_id } = req.params;
    const { status } = req.body;

    // Validate plan_id
    if (!plan_id || isNaN(parseInt(plan_id))) {
      return res.status(400).json({ error: 'Invalid plan ID' });
    }

    // Validate status
    if (!status || !['processing', 'processed'].includes(status)) {
      return res.status(400).json({ error: 'Status must be "processing" or "processed"' });
    }

    const planId = parseInt(plan_id);

    // Update the status
    const updateQuery = `
      UPDATE production_planning 
      SET status = $1 
      WHERE plan_id = $2 
      RETURNING *
    `;

    const result = await pool.query(updateQuery, [status, planId]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Production plan not found' });
    }

    res.json(result.rows[0]);

  } catch (err) {
    console.error('Error updating plan status:', err);
    res.status(500).json({ error: 'Error updating plan status' });
  }
};

// Update work order status and priority
const updateWorkOrder = async (req, res) => {
  try {
    const { plan_id, wom_id } = req.params;
    const { status, priority } = req.body;

    // Validate parameters
    if (!plan_id || isNaN(parseInt(plan_id))) {
      return res.status(400).json({ error: 'Invalid plan ID' });
    }
    if (!wom_id || isNaN(parseInt(wom_id))) {
      return res.status(400).json({ error: 'Invalid WOM ID' });
    }

    // Validate status if provided
    if (status && !['processing', 'processed'].includes(status)) {
      return res.status(400).json({ error: 'Status must be "processing" or "processed"' });
    }

    // Validate priority if provided
    if (priority && !['high', 'low'].includes(priority)) {
      return res.status(400).json({ error: 'Priority must be "high" or "low"' });
    }

    // At least one field must be provided
    if (!status && !priority) {
      return res.status(400).json({ error: 'Either status or priority must be provided' });
    }

    const planId = parseInt(plan_id);
    const womId = parseInt(wom_id);

    // Build dynamic update query
    const updates = [];
    const values = [];
    let paramCount = 0;

    if (status) {
      paramCount++;
      updates.push(`status = $${paramCount}`);
      values.push(status);
    }

    if (priority) {
      paramCount++;
      updates.push(`priority = $${paramCount}`);
      values.push(priority);
    }

    // Add WHERE clause parameters
    paramCount++;
    values.push(planId);
    const planIdParam = paramCount;

    paramCount++;
    values.push(womId);
    const womIdParam = paramCount;

    const updateQuery = `
      UPDATE work_order_management 
      SET ${updates.join(', ')}
      WHERE plan_id = $${planIdParam} AND wom_id = $${womIdParam}
      RETURNING *
    `;

    const result = await pool.query(updateQuery, values);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Work order not found' });
    }

    res.json(result.rows[0]);

  } catch (err) {
    console.error('Error updating work order:', err);
    res.status(500).json({ error: 'Error updating work order' });
  }
};

// Get PPS summary counts
const getPPSSummary = async (req, res) => {
  try {
    const { from, to } = req.query;

    // Build the base query
    let query = `
      SELECT 
        COUNT(CASE WHEN status = 'processing' THEN 1 END) as processing_count,
        COUNT(CASE WHEN status = 'processed' THEN 1 END) as processed_count
      FROM production_planning
      WHERE 1=1
    `;

    const queryParams = [];
    let paramCount = 0;

    // Add date filters if provided
    if (from) {
      paramCount++;
      query += ` AND planned_date >= $${paramCount}`;
      queryParams.push(from);
    }

    if (to) {
      paramCount++;
      query += ` AND planned_date <= $${paramCount}`;
      queryParams.push(to);
    }

    const result = await pool.query(query, queryParams);
    const summary = result.rows[0];

    res.json({
      processing_count: parseInt(summary.processing_count || 0),
      processed_count: parseInt(summary.processed_count || 0)
    });

  } catch (err) {
    console.error('Error fetching PPS summary:', err);
    res.status(500).json({ error: 'Error fetching PPS summary' });
  }
};

module.exports = {
  getAllPPS,
  getPPSStatuses,
  getPPSPriorities,
  getPPSById,
  updatePlanStatus,
  updateWorkOrder,
  getPPSSummary
};
