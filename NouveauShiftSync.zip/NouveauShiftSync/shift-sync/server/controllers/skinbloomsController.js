// server/controllers/skinbloomsController.js
// Stubbed Skinblooms metrics endpoints.
// Replace with real queries/integrations (e.g., ERP/Shopify) when available.

// NOTE: Keeping indentation consistent with existing controllers (two spaces)

// Overview KPIs
const getOverview = async (_req, res) => {
  try {
    // Example static data; wire to DB or external APIs as needed
    const overview = {
      revenueToday: 12450.75,
      ordersToday: 316,
      avgOrderValue: 39.43,
      activeSkus: 128,
      outOfStockSkus: 3
    };
    res.json(overview);
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching Skinblooms overview');
  }
};

// 14-day sales trend
const getSalesTrend = async (_req, res) => {
  try {
    const today = new Date();
    const points = Array.from({ length: 14 }).map((_, idx) => {
      const d = new Date(today);
      d.setDate(today.getDate() - (13 - idx));
      const dateStr = d.toISOString().slice(0, 10);
      // Stub pattern: mild weekly seasonality + noise
      const base = 10000;
      const seasonal = 1500 * Math.sin((idx / 7) * Math.PI);
      const noise = Math.floor(Math.random() * 800);
      return { date: dateStr, revenue: Math.round((base + seasonal + noise) * 100) / 100 };
    });
    res.json(points);
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching Skinblooms sales trend');
  }
};

// Top products
const getTopProducts = async (_req, res) => {
  try {
    const products = [
      { sku: 'SKB-LIP-001', name: 'Velvet Bloom Lipstick', unitsSold: 820, revenue: 12350.25, stockLevel: 542 },
      { sku: 'SKB-SER-014', name: 'Radiance Serum', unitsSold: 640, revenue: 18420.70, stockLevel: 120 },
      { sku: 'SKB-MSK-008', name: 'Hydra Mask', unitsSold: 590, revenue: 9720.10, stockLevel: 78 },
      { sku: 'SKB-CRM-021', name: 'Glow Day Cream', unitsSold: 510, revenue: 15110.00, stockLevel: 35 },
      { sku: 'SKB-CLN-033', name: 'Gentle Cleanser', unitsSold: 470, revenue: 8450.40, stockLevel: 260 }
    ];
    res.json(products);
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching Skinblooms top products');
  }
};

module.exports = {
  getOverview,
  getSalesTrend,
  getTopProducts,
};

