// server/controllers/dashboardController.js
const { q } = require('../db');

// GET /api/dashboard/kpis - Get aggregated KPIs from existing endpoints
const getDashboardKPIs = async (req, res) => {
  try {
    // Get current date boundaries
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Get current month boundaries
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
    const monthEnd = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    monthEnd.setHours(23, 59, 59, 999);

    // Get current week boundaries (Monday to Sunday)
    const currentDate = new Date();
    const dayOfWeek = currentDate.getDay();
    const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek; // Handle Sunday as 0
    const weekStart = new Date(currentDate);
    weekStart.setDate(currentDate.getDate() + mondayOffset);
    weekStart.setHours(0, 0, 0, 0);
    
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekStart.getDate() + 6);
    weekEnd.setHours(23, 59, 59, 999);

    // Query for orders this month (from /api/orders/summary)
    const ordersQuery = `
      SELECT 
        COUNT(*) as orders_this_month,
        COALESCE(SUM(total_amount), 0) as revenue_this_month,
        COUNT(CASE WHEN payment_status = 'paid' THEN 1 END) as paid_count,
        COUNT(CASE WHEN payment_status != 'paid' THEN 1 END) as unpaid_count
      FROM sales_orders 
      WHERE order_status != 'canceled' 
        AND order_date >= $1 AND order_date <= $2
    `;

    // Query for PPS counts (from /api/pps/summary)
    const ppsQuery = `
      SELECT 
        COUNT(CASE WHEN status = 'processing' THEN 1 END) as processing_count,
        COUNT(CASE WHEN status = 'processed' THEN 1 END) as processed_count
      FROM production_planning
    `;

    // Query for attendance this week (from /api/attendance/summary)
    const attendanceQuery = `
      SELECT 
        COALESCE(
          SUM(
            CASE 
              WHEN a.time_out IS NOT NULL THEN 
                EXTRACT(EPOCH FROM (a.time_out - a.time_in)) / 3600
              ELSE 0 
            END
          ), 
          0
        ) as total_hours_week,
        COUNT(DISTINCT DATE(a.time_in)) as active_days_count
      FROM attendance a
      WHERE DATE(a.time_in) >= $1 AND DATE(a.time_in) <= $2
    `;

    // Query for total employees (from /api/employees)
    const employeesQuery = `
      SELECT COUNT(*) as total_employees
      FROM employees
    `;

    // Execute all queries in parallel
    const [ordersResult, ppsResult, attendanceResult, employeesResult] = await Promise.all([
      q(ordersQuery, [monthStart, monthEnd]),
      q(ppsQuery),
      q(attendanceQuery, [weekStart, weekEnd]),
      q(employeesQuery)
    ]);

    // Process results
    const ordersData = ordersResult.rows[0];
    const ppsData = ppsResult.rows[0];
    const attendanceData = attendanceResult.rows[0];
    const employeesData = employeesResult.rows[0];

    // Format response with all KPIs
    const kpis = {
      orders_this_month: parseInt(ordersData.orders_this_month) || 0,
      revenue_this_month: parseFloat(ordersData.revenue_this_month) || 0,
      paid_vs_unpaid: {
        paid: parseInt(ordersData.paid_count) || 0,
        unpaid: parseInt(ordersData.unpaid_count) || 0
      },
      processing_count: parseInt(ppsData.processing_count) || 0,
      processed_count: parseInt(ppsData.processed_count) || 0,
      total_hours_week: Math.round(parseFloat(attendanceData.total_hours_week) * 100) / 100,
      active_days_count: parseInt(attendanceData.active_days_count) || 0,
      total_employees: parseInt(employeesData.total_employees) || 0
    };

    res.json(kpis);

  } catch (err) {
    console.error('Error fetching dashboard KPIs:', err);
    res.status(500).json({ error: 'Error fetching dashboard KPIs' });
  }
};

// GET /api/dashboard/recent - Get recent data for mini-tables
const getDashboardRecent = async (req, res) => {
  try {
    // Get limit from query params, default to 5, max 10
    const limit = Math.min(parseInt(req.query.limit) || 5, 10);

    // Query for recent orders (limited) - only existing columns
    const recentOrdersQuery = `
      SELECT 
        order_id,
        order_date,
        product_name,
        quantity,
        order_status,
        payment_status
      FROM sales_orders 
      WHERE order_status != 'canceled'
      ORDER BY order_date DESC, order_id DESC
      LIMIT 5
    `;

    // Query for upcoming production plans (limited) - only existing columns
    const upcomingPlansQuery = `
      SELECT 
        plan_id,
        product_name,
        planned_date,
        status,
        quantity
      FROM production_planning
      WHERE planned_date >= CURRENT_DATE
      ORDER BY planned_date ASC, plan_id ASC
      LIMIT 5
    `;

    // Query for recent attendance (limited)
    const recentAttendanceQuery = `
      SELECT 
        a.employee_id,
        DATE(a.time_in) as date,
        a.time_in,
        a.time_out,
        CONCAT(e.first_name, ' ', e.last_name) as employee_name
      FROM attendance a
      LEFT JOIN employees e ON a.employee_id = e.employee_id
      ORDER BY a.time_in DESC
      LIMIT 5
    `;

    // Execute all queries in parallel - no parameters needed since LIMIT is hardcoded
    const [ordersResult, plansResult, attendanceResult] = await Promise.all([
      q(recentOrdersQuery),
      q(upcomingPlansQuery),
      q(recentAttendanceQuery)
    ]);

    // Format the results
    const recentData = {
      recent_orders: ordersResult.rows.map(row => ({
        id: row.order_id,
        product_name: row.product_name || 'N/A',
        quantity: row.quantity || 0,
        status: row.order_status || 'pending',
        payment_status: row.payment_status || 'unpaid',
        order_date: row.order_date
      })),
      upcoming_plans: plansResult.rows.map(row => ({
        plan_id: row.plan_id,
        product_name: row.product_name || 'N/A',
        planned_date: row.planned_date,
        status: row.status || 'pending',
        quantity: row.quantity || 0
      })),
      recent_attendance: attendanceResult.rows.map(row => ({
        employee_id: row.employee_id,
        employee_name: row.employee_name || `Employee #${row.employee_id}`,
        date: row.date,
        time_in: row.time_in,
        time_out: row.time_out
      }))
    };

    res.json(recentData);

  } catch (err) {
    console.error('Error fetching dashboard recent data:', err);
    res.status(500).json({ error: 'Error fetching dashboard recent data' });
  }
};

module.exports = {
  getDashboardKPIs,
  getDashboardRecent
};
