// server/controllers/authController.js
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { pool } = require("../db");

const ONLY_BUSINESS_ID = 9; // lock to id 9
const isBcryptHash = s => typeof s === "string" && s.startsWith("$2");

async function login(req, res) {
  try {
    const { email, password } = req.body;

    // fetch only id=9 with matching email
    const { rows } = await pool.query(
      `SELECT id, name, email, slug, password_hash
       FROM businesses
       WHERE id = $1 AND email = $2
       LIMIT 1`,
      [ONLY_BUSINESS_ID, email]
    );
    if (rows.length === 0) return res.status(401).json({ error: "Email not allowed for this account" });

    const user = rows[0];
    const stored = user.password_hash || "";

    // normal login: bcrypt first; fallback to plaintext if hash isn't bcrypt
    let ok = false;
    if (isBcryptHash(stored)) {
      ok = await bcrypt.compare(password, stored);
    } else {
      ok = password === stored; // dev-only fallback (e.g., 'hashed_pw3')
    }
    if (!ok) return res.status(401).json({ error: "Incorrect password" });

    if (!process.env.JWT_SECRET) {
      return res.status(500).json({ error: "Server misconfigured: JWT_SECRET missing" });
    }

    // sign session token with JWT_SECRET (here it's literally "password")
    const token = jwt.sign(
      { bid: user.id, email: user.email, slug: user.slug },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    );

    res.cookie("ss_token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production", // false on localhost
      sameSite: "lax",
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });

    res.json({ ok: true, user: { id: user.id, name: user.name, email: user.email, slug: user.slug } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Login failed" });
  }
}

function me(req, res) {
  res.json({ me: req.user });
}

function logout(req, res) {
  res.clearCookie("ss_token", {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
  });
  res.json({ ok: true });
}

module.exports = { login, me, logout };
