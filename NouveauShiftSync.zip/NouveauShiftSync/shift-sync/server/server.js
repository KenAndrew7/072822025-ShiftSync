// server/server.js
require("dotenv").config();
const express = require("express");
const cors = require("cors");
const cookieParser = require("cookie-parser");

const app = express();

// --- middleware ---
app.use(express.json());
app.use(cookieParser());

// allow both Live Server origins
const allowed = new Set([
  "http://127.0.0.1:5500",
  "http://localhost:5500",
]);

app.use(
  cors({
    origin: (origin, cb) => cb(null, !origin || allowed.has(origin)),
    credentials: true,
  })
);

// --- routes ---
const authRoutes = require("./routes/authRoutes");
const projectRoutes = require("./routes/projectRoutes");
const taskRoutes = require("./routes/taskRoutes");
const resourceRoutes = require("./routes/resourceRoutes");
const timeRoutes = require("./routes/timeRoutes");
const skinbloomsRoutes = require("./routes/skinbloomsRoutes");
const employeeRoutes = require("./routes/employeeRoutes");
const attendanceRoutes = require("./routes/attendanceRoutes");
const orderRoutes = require("./routes/orderRoutes");
const ppsRoutes = require("./routes/ppsRoutes");
const dashboardRoutes = require("./routes/dashboardRoutes");
const healthRoutes = require("./routes/healthRoutes");
const notificationRoutes = require("./routes/notificationRoutes");

app.use("/auth", authRoutes);
app.use("/api/projects", projectRoutes);
app.use("/api/tasks", taskRoutes);
app.use("/api/resources", resourceRoutes);
app.use("/api/time-tracking", timeRoutes);
app.use("/api/skinblooms", skinbloomsRoutes);
app.use("/api/employees", employeeRoutes);
app.use("/api/attendance", attendanceRoutes);
app.use("/api/orders", orderRoutes);
app.use("/api/pps", ppsRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/health", healthRoutes);
app.use("/api/task-notifications", notificationRoutes);

const { q } = require("./db");
app.get("/healthz", async (_req, res) => {
  try {
    const r = await q("select now()");
    res.json({ ok: true, time: r.rows[0].now });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// --- start ---
const PORT = process.env.PORT || 5000;
const server = app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('🛑 SIGTERM received, shutting down gracefully...');
  try {
    // Close HTTP server
    server.close(() => {
      console.log('📡 HTTP server closed');
    });
    
    // Close database pool
    const { pool } = require('./db');
    await pool.end();
    console.log('🗄️  Database pool closed');
  } catch (error) {
    console.error('❌ Error during graceful shutdown:', error);
  } finally {
    console.log('👋 Process exiting');
    process.exit(0);
  }
});

process.on('SIGINT', async () => {
  console.log('🛑 SIGINT received, shutting down gracefully...');
  try {
    server.close(() => {
      console.log('📡 HTTP server closed');
    });
    
    const { pool } = require('./db');
    await pool.end();
    console.log('🗄️  Database pool closed');
  } catch (error) {
    console.error('❌ Error during graceful shutdown:', error);
  } finally {
    console.log('👋 Process exiting');
    process.exit(0);
  }
});
