// server/db/pool.js
const { Pool } = require('pg');

// Validate Neon database URL format
const databaseUrl = process.env.NEON_DATABASE_URL || process.env.DATABASE_URL;
if (databaseUrl && !databaseUrl.includes('?sslmode=require')) {
  console.warn('⚠️  Database URL should end with ?sslmode=require for Neon');
  console.warn('   Expected format: postgres://user:pass@host-pooler.region.neon.tech/neondb?sslmode=require');
}

// Create connection pool with Neon-optimized settings
const pool = new Pool({
  connectionString: databaseUrl,                    // must end with ?sslmode=require
  ssl: { rejectUnauthorized: false },               // Neon requires SSL
  max: 10,                                          // Maximum number of connections
  idleTimeoutMillis: 30000,                        // Close idle connections after 30s
  connectionTimeoutMillis: 10000,                  // Timeout after 10s if no connection available
  keepAlive: true,                                  // Keep connections alive
});

// Handle unexpected pool errors gracefully (don't crash the process)
pool.on('error', (err) => {
  console.error('Unexpected PG pool error', err);
});

// Enhanced query function with lightweight retry for transient connection drops
async function q(text, params) {
  // Retry up to 2 times for transient connection issues
  for (let i = 0; i < 2; i++) {
    try {
      return await pool.query(text, params);
    } catch (e) {
      // Check if error is transient (connection issues)
      const transient = 
        e?.message?.includes('Connection terminated') ||
        e?.message?.includes('connection is closed') ||
        e?.code === '57P01' ||  // ADMIN_SHUTDOWN
        e?.code === 'ECONNRESET' ||
        e?.code === 'ENOTFOUND' ||
        e?.code === 'ETIMEDOUT';
      
      // If this is the last attempt or not a transient error, throw it
      if (i === 1 || !transient) {
        console.error(`Database query failed (attempt ${i + 1}/2):`, {
          error: e.message,
          code: e.code,
          query: text.substring(0, 100) + (text.length > 100 ? '...' : '')
        });
        throw e;
      }
      
      // Wait 300ms before retry
      console.warn(`Transient database error, retrying in 300ms:`, e.message);
      await new Promise(resolve => setTimeout(resolve, 300));
    }
  }
}

// Export both the pool and the query function
module.exports = { 
  pool, 
  q,
  // Legacy export for backward compatibility
  default: pool 
};
