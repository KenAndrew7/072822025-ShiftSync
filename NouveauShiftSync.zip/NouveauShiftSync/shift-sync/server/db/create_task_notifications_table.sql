-- Create task_notifications table
CREATE TABLE IF NOT EXISTS task_notifications (
    id SERIAL PRIMARY KEY,
    task_id INTEGER NOT NULL,
    department VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index on department for faster filtering
CREATE INDEX IF NOT EXISTS idx_task_notifications_department ON task_notifications (department);

-- Create index on created_at for faster ordering
CREATE INDEX IF NOT EXISTS idx_task_notifications_created_at ON task_notifications (created_at DESC);

-- Create index on task_id for potential foreign key lookups
CREATE INDEX IF NOT EXISTS idx_task_notifications_task_id ON task_notifications (task_id);

-- Create index on read status for filtering unread notifications
CREATE INDEX IF NOT EXISTS idx_task_notifications_read ON task_notifications (read);
