// server/db/index.js
// Import the enhanced pool configuration
const { pool, q } = require('./pool');

// Environment variable validation
if (!process.env.NEON_DATABASE_URL && !process.env.DATABASE_URL) {
  console.error("❌ NEON_DATABASE_URL or DATABASE_URL is missing from .env");
  console.error("   For Neon, use: NEON_DATABASE_URL=postgres://user:pass@host-pooler.region.neon.tech/neondb?sslmode=require");
  console.error("   Make sure to use the pooler host (contains '-pooler') for better performance");
  // don't throw; let app start so you can see the message
}

// Export pool and query function for backward compatibility
module.exports = { 
  pool,
  q,
  // Legacy exports
  default: pool
};
